import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {SharedModule} from './shared/shared.module';
import { RouterModule } from '@angular/router';


import {routes} from './app.routing';

import { VoiceActorCardComponent } from './components/voice-actor-card/voice-actor-card.component';
import { ActorsSummaryComponent } from './components/actors-summary/actors-summary.component';

@NgModule({
  declarations: [
    AppComponent,
    VoiceActorCardComponent,
    ActorsSummaryComponent
  ],
  imports: [
    SharedModule,
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
