import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'voice-actor-card',
  templateUrl: './voice-actor-card.component.html',
  styleUrls: ['./voice-actor-card.component.css']
})
export class VoiceActorCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
