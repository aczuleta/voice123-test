export class Actor {
    constructor(public name:string, public profilePic:string, public summary:string, public voiceSample:string){}
}