import { Component, OnInit } from '@angular/core';
import {VoiceActorCardComponent} from '../voice-actor-card/voice-actor-card.component';

@Component({
  selector: 'actors-summary',
  templateUrl: './actors-summary.component.html',
  styleUrls: ['./actors-summary.component.css']
})
export class ActorsSummaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
