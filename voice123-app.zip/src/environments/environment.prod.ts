export const environment = {
  production: true,
  apiVoice: "https://api.sandbox.voice123.com/providers/search/"
};
