// src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Sucursal } from '../models/sucursal';
import { Actor } from '../models/actor';

@Injectable({
    providedIn: 'root',
})
export class ActorsService {
    private env = environment;
    constructor(private http: HttpClient) { }
    public paises() {
        return this.http.get(this.env.apiVoice + '/api/cnf_paises');
    }
}